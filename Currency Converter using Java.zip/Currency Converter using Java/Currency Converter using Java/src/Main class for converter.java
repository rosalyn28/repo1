import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

class Currency {
    private String name;
    private String shortName;
    private HashMap<String, Double> exchangeValues;

    public Currency(String name, String shortName) {
        this.name = name;
        this.shortName = shortName;
        this.exchangeValues = new HashMap<>();
    }

    public void addExchangeRate(String currency, double rate) {
        exchangeValues.put(currency, rate);
    }

    public double convertTo(String targetCurrency, double amount) {
        return amount * exchangeValues.getOrDefault(targetCurrency, 0.0);
    }

    public String getShortName() {
        return shortName;
    }
}

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CurrencyConverterGUI().setVisible(true));
    }
}

class CurrencyConverterGUI extends JFrame {
    private JComboBox<String> sourceCurrency;
    private JComboBox<String> targetCurrency;
    private JTextField amountField;
    private JLabel resultLabel;
    private HashMap<String, Currency> currencies;

    public CurrencyConverterGUI() {
        setTitle("Currency Converter");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2));

        // Initialize currencies
        currencies = new HashMap<>();
        Currency usd = new Currency("US Dollar", "USD");
        Currency eur = new Currency("Euro", "EUR");
        Currency inr = new Currency("Indian Rupee", "INR");

        usd.addExchangeRate("EUR", 0.92);
        usd.addExchangeRate("INR", 83.10);
        eur.addExchangeRate("USD", 1.09);
        eur.addExchangeRate("INR", 90.00);
        inr.addExchangeRate("USD", 0.012);
        inr.addExchangeRate("EUR", 0.011);

        currencies.put("USD", usd);
        currencies.put("EUR", eur);
        currencies.put("INR", inr);

        // UI Components
        sourceCurrency = new JComboBox<>(new String[]{"USD", "EUR", "INR"});
        targetCurrency = new JComboBox<>(new String[]{"USD", "EUR", "INR"});
        amountField = new JTextField();
        JButton convertButton = new JButton("Convert");
        resultLabel = new JLabel("Result: ");

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertCurrency();
            }
        });

        add(new JLabel("From:"));
        add(sourceCurrency);
        add(new JLabel("To:"));
        add(targetCurrency);
        add(new JLabel("Amount:"));
        add(amountField);
        add(convertButton);
        add(resultLabel);
    }

    private void convertCurrency() {
        String source = (String) sourceCurrency.getSelectedItem();
        String target = (String) targetCurrency.getSelectedItem();
        double amount;
        try {
            amount = Double.parseDouble(amountField.getText());
        } catch (NumberFormatException e) {
            resultLabel.setText("Invalid amount");
            return;
        }

        Currency sourceCurr = currencies.get(source);
        double convertedAmount = sourceCurr.convertTo(target, amount);
        resultLabel.setText("Result: " + convertedAmount + " " + target);
    }
}
